from urllib.request import Request, urlopen
from config import config

config = config()

def bot_info_call():
    """
    bot 의 정보를 출력하는 함수
    """

    #request 객체만들기
    #url과 요청할 메소드(get,post)를 정해줘야한다
    request = Request(config.BOT_INFO)
    request.get_method = lambda: 'GET'

    #requset객체를 만들었으므로 실제로 요청을 보내고 response를 받아온다
    response_body = urlopen(request).read().decode('utf-8')

    print(response_body)


def bot_update_call():
    """
    bot 의 업데이트 정보를 출력하는 함수
    """
    request = Request(config.BOT_UPDATE)
    print(config.BOT_UPDATE)
    request.get_method = lambda: 'GET'
    response_body = urlopen(request).read().decode('utf-8')
    print(response_body)


def bot_set_webhook_call():
    """
    bot 의 Webhook 을 세팅하는 함수
    """
    request = Request(config.BOT_SET_WEBHOOK)
    request.get_method = lambda: 'GET'
    response_body = urlopen(request).read().decode('utf-8')
    print(response_body)


def delete_webhook():
    """
    bot 의 Webhook 을 제거하는 함수
    """
    request = Request(config.BOT_DELETE)
    request.get_method = lambda: 'GET'
    response_body = urlopen(request).read().decode('utf-8')
    print(response_body)

def get_webhook_info():
    request = Request(config.BOT_GET_INFO)
    request.get_method = lambda: 'GET'
    response_body = urlopen(request).read().decode('utf-8')
    print(response_body)

if __name__ == '__main__':

#    bot_info_call()
    delete_webhook()
#    bot_update_call()
    bot_set_webhook_call()
#    get_webhook_info()