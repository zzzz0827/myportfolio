from config import config
config = config()

def make_connection():

    conn = pymysql.connect(
        host=config.host_name,  # DATABASE_HOST
        port=3306,
        user=config.username,  # DATABASE_USERNAME
        passwd=config.password,  # DATABASE_PASSWORD
        db=config.database_name,  # DATABASE_NAME
        charset='utf8'
    )
    return conn

def is_new_member(chat_id):

    conn = make_connection()
    curs = conn.cursor()

    sql = "SELECT count(*) FROM telegram_user_tb WHERE id={}".format(chat_id)

    curs.execute(sql)

    isExist = curs.fetchone()[0]

    conn.close()

    if isExist:
        return False
    else:
        return True


def insert_user(chat_id,name):
    conn = make_connection()
    sql = "INSERT INTO telegram_user_tb (id,user_id) VALUE (%s,%s)"

    val = (chat_id,name)

    mycursor = conn.cursor()
    mycursor.execute(sql,val)
    conn.commit()

    conn.close()

if __name__ == "__main__":
    print(is_new_member("964322422"))