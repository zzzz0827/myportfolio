import requests
from config import config
config = config()
import db_functions as db


class telegrambot:

    def __init__(self):

        self.chat_id = None
        self.data = None
        self.name = None
        self.data_type = None
        self.is_member = False
        self.message_id = None

    def __call__(self, input_data):

        # 단순한 텍스트 입력일때
        if not 'callback_query' in input_data.keys():

            chat_id = input_data['message']['chat']['id']
            msg = input_data['message']['text']
            user_name = input_data['message']['chat']['last_name'] + input_data['message']['chat']['first_name']
            message_id = input_data['message']['message_id']

            self.chat_id = str(chat_id)
            self.data =msg
            self.name = user_name
            self.message_id = message_id
            self.data_type = "text"


        # inline keyboard 입력일때
        else:
            chat_id = input_data['callback_query']['from']['id']

            user_name = input_data['callback_query']['from']['first_name'] + input_data['callback_query']['from']['last_name']
            self.chat_id = str(chat_id)
            self.data = input_data['callback_query']['message']
            self.name = user_name
            self.message_id = self.data['message_id']
            self.data_type = "inline_keyboard"


        # # db 처리(사용자등록)
        # is_new =db.is_new_member(self.chat_id)
        #
        # if is_new:
        #     db.insert_user(self.chat_id,self.name)
        #
        # else:
        #     self.is_member = True
        #     #상태 가져오기 등등



    def send_message(self,text):
        if text == '/start':
            text = '안녕하세요! 저는 여울이에요!\n저는 여러분들이 모르는 철도 정보를 알려 줄 수 있어요!\n궁금한게 있으면 언제든지 저를 불러주세요!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '노선' in text:
            text = '수도권 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '호선' in text and '인천' not in text :
            number = text[0]
            text = "{}호선 노선도를 출력합니다!".format(number)
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '인천' in text :
            number = text[2]
            if number == " " :
                number = text[3]
            text = '인천{}호선 노선도를 출력합니다!'.format(number)
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '분당' in text and '신분당' not in text:
            text = '분당선 노선도를 출력합니다!\n분당 최고의 영어강사 엽동정!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '신분당' in text :
            text = '신분당선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경의' in text or '중앙' in text:
            text = '경의중앙선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경춘' in text :
            text = '경춘선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        
        elif '공항' in text :
            text = '공항철도 노선도를 출력합니다!\n오늘 비행기의 추락 확률은 0%에서 100% 사이입니다.'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        
        elif '의정부' in text :
            text = '의정부 경전철 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '수인' in text :
            text = '수인선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '에버' in text or '라인' in text:
            text = '에버라인 노선도를 출력합니다!\n환상의 나라로 오세요'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '자기' in text or '부상' in text:
            text = '자기부상선 노선도를 출력합니다!\n아이언맨이 움직입니다.'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경강' in text :
            text = '경강선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '우이' in text or '신설' in text:
            text = '우이신설선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '서해' in text :
            text = '서해선 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '김포' in text or '골드' in text:
            text = '김포골드선 노선도를 출력합니다!\n황금로드'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        elif '여울' in text:
            text = "여울이는 반으로 갈라져 죽었다."
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        elif '희수' in text:
            text = '정희수 ♥ 권기현'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        else:
            text = '제가 아직 모르는 노선도에요..\n혹시 1~9호선 뒤에 "호선"을 안붙이셨나요?'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            

    def send_message_with_keyboard(self,text,keyboard):

        params = {'chat_id': self.chat_id, 'text': text, 'reply_markup':keyboard}
        requests.post(config.SEND_MESSAGE, json=params)

    def send_photo(self,text):
        number = text[0]
        if '인천' in text :
            number = text[2]
            
        if '노선' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190924/smap_sg_all.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '호선' in text and '인천' not in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg{}.png'.format(number)}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '인천' in text and number == '1' :
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_ic.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '인천' in text and number == '2' :
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_ic2.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '분당' in text and '신분당' not in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_bd.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '신분당' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_sbd.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '경의' in text or '중앙' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_gu.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '경춘' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_gc.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '공항' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190924/smap_sg_ap.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '의정부' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_ujb.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '수인' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_si.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '에버' in text or '라인' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_ev.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '자기' in text or '부상' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_mag.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '경강' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_gg.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '우이' in text or '신설' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_us.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '서해' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190808/smap_sg_sh.png'}
            requests.post(config.SEND_PHOTO, json=params)
            
        elif '김포' in text or '골드' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://ssl.pstatic.net/sstatic/keypage/outside/subway/img/190924/smap_sg_kpgold.png'}
            requests.post(config.SEND_PHOTO, json=params)
        elif '여울' in text:
            params = {'chat_id': self.chat_id, 'photo': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTe5e_1egiF4c-ZcgLR_EyLEmKSENzkYMALOsun_dn3AQQJQL_lhA&s'}
            requests.post(config.SEND_PHOTO, json=params)
        

    def send_message2(self,text):
            
        if '노선' in text:
            text = '수도권 노선도를 출력합니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '호선' in text and '인천' not in text :
            number = text[0]
            if number == '1':
                text = '1974년 8월 15일에 운행 시작한 한국 최초의 광역 철도로, 종착역은 인천, 소요산, 신창역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '2':
                text = '1984년 5월 2일에 운행 시작한 순환 철도로, 종점은 성수역, 신도림역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '3':
                text = '1985년에 개통된 철도로, 경기도 고양시와 서울을 잇는 지하철입니다. 종착역은 오금, 대화역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '4':
                text = '1985년에 개통된 철도로, 기해 안산선, 경부선이 폐지되고 나타난 지하철입니다. 종착역은 오이도, 당고개역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '5':
                text = '1995년에 개통된 철도로, 강동구, 송파구를 잇는 지하철입니다. 종착역은 방화, 상일동, 마천역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '6':
                text = '2000년에 개통한 철도로, 응암역을 기점으로 순환하고 봉화산역에서 종착하는 지하철입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '7':
                text = '1996년에 개통한 철도로, 서울 지하철 유일 인천까지 확장한 지하철입니다. 종착역은 부평구청, 장암역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '8':
                text = '1996년에 개통한 철도로, 1~9호선 중에서 가장 역이 적은 지하철입니다. 종착역은 암사, 모란역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '9':
                text = '2009년에 개통한 철도로, 급행열차가 가장 많은 지하철입니다. 종착역은 개화, 중앙보훈병원역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
                
            
        elif '인천' in text :
            number = text[2]
            if number == " " :
                number = text[3]
            if number == '1':
                text = '1999년에 개통한 철도로, 경인선 개통 후 100년만에 제작된 지하철입니다. 종착역은 계양, 국제업무지구역입니다!'
                params = {'chat_id': self.chat_id, 'text': text}
                requests.post(config.SEND_MESSAGE, json=params)
            elif number == '2':
                text = '2016년에 개통한 철도로, 전동차 형태를 이루고 있는 지하철입니다. 종착역은 검단오류, 운연역입니다!'
            
        elif '분당' in text and '신분당' not in text:
            text = '1994년 개통한 철도로, 분당이 아닌 서울에 역을 더 많이 둔 지하철입니다. 종착역은 청량리, 수원역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '신분당' in text :
            text = '2011년에 개통한 철도로, 무인임에도 불구하고 최고속도가 90km/h가 되는 지하철입니다. 종착역은 강남, 광교역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경의' in text or '중앙' in text:
            text = '2014년에 개통한 철도로, 2번째로 가장 긴 지하철입니다. 종착역은 문산, 지평, 서울역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경춘' in text :
            text = '2010년에 개통한 철도로, 터널이 매우 긴 지하철입니다. 종착역은 청량리, 광운대역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        
        elif '공항' in text :
            text = '2007년에 개통된 철도로, 공항으로 가는 몇 안되는 지하철입니다. 종착역은 서울, 인천공항2터미널역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        
        elif '의정부' in text :
            text = '2012년에 개통한 철도로, 수도권 최초로 개통된 경전철입니다. 종착역은 발곡, 탑석역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '수인' in text :
            text = '1937년 개통된 수인선을 표준궤로 개량한 노선입니다. 종착역은 인천, 오이도역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '에버' in text or '라인' in text:
            text = '2013년에 개통된 철도로, 에버랜드가 종착역인 전철입니다. 종착역은 기흥, 전대 에버랜드역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '자기' in text or '부상' in text:
            text = '2016년에 개통된 철도로, 한국 최초의 상용 자기부상열차입니다. 종착역은 인천공항1터미널, 용유역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '경강' in text :
            text = '2016년에 개통된 철도로, 수도권의 판교역과 여주역을 잇는 열차입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '우이' in text or '신설' in text:
            text = '2017년 개통된 철도로, 서울 경전철의 첫번째 노선입니다. 종착역은 북한산우이, 신설동역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '서해' in text :
            text = '2018년에 개통된 철도로, 원시역에서 소사역을 잇는 열차입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
            
        elif '김포' in text or '골드' in text:
            text = '2019년에 개통된 가장 최근에 개통된 지하철로, 종착역은 양촌, 김포공항역입니다!'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        elif '여울' in text:
            text = "여울이는 반으로 갈라져 죽었다."
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        elif '희수' in text:
            text = '정희수 ♥ 권기현'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
        else:
            text = '제가 아직 모르는 노선도에요..\n혹시 1~9호선 뒤에 "호선"을 안붙이셨나요?'
            params = {'chat_id': self.chat_id, 'text': text}
            requests.post(config.SEND_MESSAGE, json=params)
