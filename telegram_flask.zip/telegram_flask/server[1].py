from flask import Flask,request
from bot import telegrambot
from button_maker import inline_sample,keyboard_sample

app = Flask(__name__)

@app.route('/',methods=['POST','GET'])
def index():

    if request.method == "POST":

        data = request.get_json()

        bot = telegrambot()
        bot(data)

        print("사용자 id : ",bot.chat_id)
        print("사용자 이름 : ",bot.name)
        print("사용자가 보낸 메세지 : ",bot.data)
        
        bot.send_message(bot.data)
        


        
        if '호선' in bot.data or '인천' in bot.data or '분당' in bot.data or '경의' in bot.data or '중앙' in bot.data or '경춘' in bot.data or '공항' in bot.data or '의정부' in bot.data or '수인' in bot.data or '노선' in bot.data or '희수' in bot.data:
            bot.send_photo(bot.data)
        elif '에버' in bot.data or'라인' in bot.data or '자기' in bot.data or '부상' in bot.data or '경강' in bot.data or '우이' in bot.data or '신설' in bot.data or '김포' in bot.data or '골드' in bot.data or '서해' in bot.data or '여울' in bot.data:
            bot.send_photo(bot.data)
        else:
            bot.send_photo(bot.data)

        bot.send_message2(bot.data)

    return ''



if __name__ == "__main__":
    app.run(host = "localhost",port = 5000)