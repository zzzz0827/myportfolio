from flask import Flask,request
import requests
from bot import telegrambot
from config import config
config = config()

import button_maker

app = Flask(__name__)

@app.route('/',methods=['POST','GET'])
def index():

    if request.method == "POST":

        data = request.get_json()
        bot = telegrambot()
        bot(data)
        print(data)

        firstQ = {
            'keyboard': [[{'text': '지하철 노선'}, {'text': '지하철 역사 확인'}]]
        }
        bot.send_message_with_keyboard("원하시는 메뉴를 선택해주세요", firstQ)

        print(data)




    return ''


if __name__ == "__main__":
    app.run(host = "localhost",port = 5000)