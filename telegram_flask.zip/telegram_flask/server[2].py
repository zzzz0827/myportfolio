from flask import Flask,request
from bot import telegrambot



app = Flask(__name__)

@app.route('/',methods=['POST','GET'])
def index():

    if request.method == "POST":

        data = request.get_json()
        print(data)
        bot = telegrambot()
        bot(data)

        #reply_keyboard도 결국은 text input이다
        if bot.data_type =="text":

            #텍스트 컨트롤러
            pass

        elif bot.data_type == "inline_keyboard":

            #inline버튼 컨트롤러
            pass

        else:
            pass



    return ''




if __name__ == "__main__":
    app.run(debug=True, host = "localhost",port = 5000)

